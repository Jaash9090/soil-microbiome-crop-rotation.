import streamlit as st
from engine import recommend

st.set_page_config(page_title="Soil Crop Rotation Demo", page_icon="🌱", layout="centered")
st.title("🌱 Soil Microbiome & Crop Rotation")
st.caption("Educational rule-based recommendation prototype • Group 26P_3CSE348")
st.info("This version uses soil pH, nitrogen status and crop-family history. Microbiome sequencing data is NOT yet integrated. Scores are illustrative, not scientifically validated.")
with st.form("recommendation_form"):
    ph = st.slider("Soil pH", min_value=0.0, max_value=14.0, value=6.8, step=0.1)
    nitrogen = st.selectbox("Soil nitrogen status", ["low", "adequate"])
    previous = st.selectbox("Previous crop family", ["Poaceae", "Fabaceae", "Other", "None"])
    submitted = st.form_submit_button("Recommend crops", type="primary")
if submitted:
    results = recommend(ph, nitrogen, previous)
    st.subheader("Ranked candidate crops")
    st.dataframe([{"Crop": r["crop"], "Family": r["family"], "Illustrative score / 100": r["score"]} for r in results], hide_index=True, use_container_width=True)
    st.subheader("Explanation")
    for r in results:
        with st.expander(f"{r['crop']} — {r['score']}/100", expanded=r == results[0]):
            st.write(f"Soil pH suitable: {'Yes' if r['ph_ok'] else 'No'} (+{50 if r['ph_ok'] else 0})")
            st.write(f"Crop family changed: {'Yes' if r['family_change'] else 'No'} (+{30 if r['family_change'] else 0})")
            st.write(f"Nitrogen demand compatible: {'Yes' if r['nitrogen_ok'] else 'No'} (+{20 if r['nitrogen_ok'] else 0})")
st.divider()
st.caption("Created as a classroom prototype by Harsh Aryan, Murari Kumar, Palak Singh and Ashish Joshi. Consult agronomy experts before real farming decisions.")
