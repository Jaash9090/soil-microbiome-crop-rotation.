import unittest
from engine import recommend

class RecommendationTests(unittest.TestCase):
    def test_chickpea_is_top_for_sample(self):
        self.assertEqual(recommend(6.8, "low", "Poaceae")[0]["crop"], "Chickpea")
    def test_bad_ph(self):
        with self.assertRaises(ValueError):
            recommend(-1, "low", "Poaceae")
    def test_bad_nitrogen(self):
        with self.assertRaises(ValueError):
            recommend(6.8, "unknown", "Poaceae")
    def test_family_penalty(self):
        maize = next(x for x in recommend(6.8, "adequate", "Poaceae") if x["crop"] == "Maize")
        self.assertFalse(maize["family_change"])

if __name__ == "__main__":
    unittest.main()
