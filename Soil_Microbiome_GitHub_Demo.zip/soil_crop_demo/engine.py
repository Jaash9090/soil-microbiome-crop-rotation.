"""Educational crop rotation recommender; not agronomic advice."""
CROPS = [
    {"name": "Chickpea", "family": "Fabaceae", "ph_min": 6.0, "ph_max": 8.0, "nitrogen_demand": "low"},
    {"name": "Wheat", "family": "Poaceae", "ph_min": 6.0, "ph_max": 7.5, "nitrogen_demand": "high"},
    {"name": "Maize", "family": "Poaceae", "ph_min": 5.8, "ph_max": 7.5, "nitrogen_demand": "high"},
    {"name": "Soybean", "family": "Fabaceae", "ph_min": 6.0, "ph_max": 7.5, "nitrogen_demand": "low"},
]

def recommend(ph: float, nitrogen_status: str, previous_family: str):
    if not 0 <= ph <= 14:
        raise ValueError("pH must be between 0 and 14")
    if nitrogen_status not in ("low", "adequate"):
        raise ValueError("Invalid nitrogen status")
    if previous_family not in ("Poaceae", "Fabaceae", "Other", "None"):
        raise ValueError("Invalid previous crop family")
    results = []
    for crop in CROPS:
        ph_ok = crop["ph_min"] <= ph <= crop["ph_max"]
        family_change = previous_family in ("Other", "None") or crop["family"] != previous_family
        nitrogen_ok = nitrogen_status == "adequate" or crop["nitrogen_demand"] == "low"
        score = 50 * ph_ok + 30 * family_change + 20 * nitrogen_ok
        results.append({"crop": crop["name"], "family": crop["family"], "score": score,
                        "ph_ok": ph_ok, "family_change": family_change, "nitrogen_ok": nitrogen_ok})
    return sorted(results, key=lambda row: (-row["score"], row["crop"]))
