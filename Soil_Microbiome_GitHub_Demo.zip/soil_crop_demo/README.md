# Soil Microbiome Recommendation Engine for Crop Rotation — Demo

**Group ID:** 26P_3CSE348  
**Section:** 3CSE16  
**Members:** Harsh Aryan, Murari Kumar, Palak Singh, Ashish Joshi

## What this prototype does

A Streamlit web app ranks four illustrative crop candidates using soil pH, nitrogen status, and previous crop family. It provides transparent score explanations. **This is a rule-based demonstration, not a trained microbiome AI model or validated farming guidance.** No microbiome assay data is integrated yet.

## Files

- `app.py` — Streamlit user interface
- `engine.py` — rule-based recommendation engine
- `requirements.txt` — dependency list
- `test_engine.py` — automated unit tests

## Run locally

```bash
python -m pip install -r requirements.txt
streamlit run app.py
```

Open the local URL shown in your terminal (normally `http://localhost:8501`).

## Run tests

```bash
python -m unittest discover -v
```

## Publish on GitHub + Streamlit Community Cloud

1. Create a **public GitHub repository** (for example `soil-microbiome-crop-rotation`).
2. Upload the **contents** of this folder to the repository root, including `app.py` and `requirements.txt`.
3. Commit changes to the `main` branch.
4. Visit https://share.streamlit.io/ and sign in with GitHub.
5. Choose **Create app** → **Yup, I have an app** (labels may vary).
6. Select your repository, branch `main`, and entrypoint `app.py`.
7. Click Deploy and wait for the app to build. Streamlit will provide a public URL if deployment succeeds.

## Example demo input

- pH: `6.8`
- Nitrogen: `low`
- Previous family: `Poaceae`

Expected top recommendation: Chickpea, score 100 (illustrative).

## Scoring logic

- +50 for pH inside the crop's illustrative range
- +30 if previous and candidate crop families differ
- +20 if nitrogen status is adequate or crop demand is low

Weights and crop ranges are placeholders for teaching, not field-validated recommendations.

## Future scope

Integrate laboratory-derived soil microbiome data, verify regional crop requirements, validate with agronomists, and evaluate against real crop rotation outcomes.
